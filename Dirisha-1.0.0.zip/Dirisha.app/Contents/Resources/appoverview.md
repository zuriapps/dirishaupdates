Dirisha App – Essentials Overview (Compact)

**What Dirisha Does**
Dirisha is a macOS window management app similar to Magnet, but with advanced group-based configurations. Users can create saved "configurations" containing multiple apps and define different position layouts (position groups) for each configuration. For example, a "Work" configuration might have Safari, Xcode, and Terminal arranged in "Left Half + Right Corners" layout, while a "Design" configuration could have the same apps in a "Four Corners" layout. Users can quickly switch between configurations via UI buttons or keyboard shortcuts, and the app automatically positions all apps in the selected layout. It supports corners, halves, thirds, and custom combinations with precise anchoring and size enforcement.

Architecture and Windows
- Single main window: `Window("Dirisha", id: "mainWindow")`. No duplicates.
- Attached menu bar mode reuses main window under status bar; toggle show/hide; Escape and outside click hide.
- Dock icon visibility is smart: accessory mode when status item accessible; regular when hidden. Ensures reliable global shortcuts without flicker.
- Window launch: default 600×720, centered; smooth enforce-to-minimum on first resolve (not in menu bar mode).

Menu Bar Mode
- Fixed compact width/height: Home ~545pt; Settings/Shortcuts ~745pt; automatic height adjust and re-anchoring on resize/tab changes.
- Auto-hide on outside click (local + global monitors). Edit flows auto-hide and restore the window.
- Plus button enlarged with hover scale; mini glassmorphic buttons for actions with semantic colors.

Activation and Positioning
- Actions use single-pass `summon()`; removed redundant `repin()`; 10ms staggers. Smooth swaps/rotations also at 10ms.
- Invisible height enforcement after initial move fixes half-screen min-size apps.
- Special operations: half+corner swap/rotate; new 3‑app half+corners templates with rotation support.

Data and Performance
- Replaced heavy `@Query` with manual `FetchDescriptor` loads and local caches; `.onAppear` refresh in menu bar view.
- Pre-computed per-row values (counts, icons, groups) eliminate scroll lag.
- Sync triggers: `AppState.configurationDataVersion` notifies views to refresh cached displays after edits.

Permissions
- Blocking authorization UI (main and menu bar) until Accessibility granted. Smart detection on app activation/foreground with efficient timers. Opens directly to Privacy > Accessibility.

Keyboard Shortcuts
- Forward/backward configuration cycling; position group cycling; toggle menu bar.
- Cycling order: by `lastActivatedAt` (fallback `dateCreated`); timestamps not updated during cycling to avoid loops.

UX and Styling
- Glassmorphic button styles (regular, destructive, adaptive, and mini) with hover/scale effects; theme-adaptive text colors.
- Position group pickers show SF Symbols via `SFSymbolTemplateMapper`; default/custom marked with star.
- Template selection uses SF Symbols only (no custom grid).

Missing Apps
- Detects missing apps before activation; modal offers Continue/Cancel/App Store; partial activation supported.

Theme
- Theme setting: System, Light, Dark (default first-run Dark). Centralized appearance via `AppState.applyAppearance(for:)` applied on launch and changes; no light→dark flash.

Notable Fixes
- No duplicate windows; instant menu bar transitions; persistent attached anchoring; correct height after tab switches; smooth configuration transitions; consistent dropdown sizing/truncation.
- Smart dock icon policy now keeps the dock presence in main window mode, auto-attaches for shortcut activation, and hides the dock only during menu bar attachment.

Key Files Touched
- `AppState.swift`, `DirishaApp.swift`, `WindowAccessor.swift`
- Views: `MainView.swift`, `ContentView.swift`, `MinimizedHomeView.swift`, `AppConfigurationsSectionView.swift`, `SavedApplicationsSectionView.swift`, `ShortcutsView.swift`, `MissingAppModal.swift`
- Menu Bar: `Views/MenuBar/MenuBarManager.swift` (status icon appearance isolation with retry-based protection)
- Styling: `Views/Styling/*`
- Utils/Components: `MissingAppDetector.swift`, `SFSymbolTemplateMapper.swift`

Change Log Organization
- UI (Main App Mode): `App Context/UI Context/Main App Mode/Main App Mode Bug Fixes/MAINAPPMODEREADME.md`
- UI (Menu Bar Mode): `App Context/UI Context/Menu Bar Mode/Menu Bar Mode Bug Fixes/MENUBARMODEREADME.md`
- Swift Data: `App Context/SWIFT Data/SWIFTDATAREADME.md`
- Pinning Engine: `App Context/Pinning Engine/PINCOREREADME.md`
- App Orchestration: `App Context/App Orchestration/APPSTATEREADME.md`
- App Setup: `App Context/App Setup/DIRISHAAPPREADME.md`
- App Updates: `App Context/App Updates/APPUPDATESREADME.md`
- Keyboard Shortcuts: `App Context/Keyboard Shortcuts/KEYBOARDSHORTCUTSREADME.md`
- Multi-Monitor Support: `App Context/Multi-Monitor Support/MULTIMONITORREADME.md`

Guideline: Log future changes in the specific area README instead of expanding this overview. When a change touches multiple areas (e.g., Swift Data + PinCore), update each corresponding README. If a new area emerges (e.g., "Accessibility", "Keyboard Shortcuts", "Menu Bar Infrastructure"), create a folder under `App Context/` with a README using the same entry template and reference it here.

Compliance Checks
- 2025-09-28: Reviewed Apple third-party SDK privacy manifest requirements; current dependencies (`KeyboardShortcuts`, `LaunchAtLogin`) are not on the required manifest list, so no `Info.plist` updates are needed. Reference: https://developer.apple.com/support/third-party-SDK-requirements/
- 2025-09-29: Documentation flow update: `CLAUDE.md` now directs Claude Code to use `Read(Dirisha/App Context/appoverview.md)` so the assistant reliably loads this overview before other docs.

Backend Architecture (Core Summary)
- SwiftData models:
  - `SavedApp`: persisted app (bundleID, name) with default size, corner, width fraction, and margins.
  - `ConfigurationGroup`: a named set of `AppConfiguration` entries plus multiple `PositionGroup` variants; tracks `lastActivatedAt` for recency and default group by ID; stores original screen size for scaling.
  - `AppConfiguration`: app entry in a configuration (bundleID, appName) with saved corner/size/margins and flags (priority, required).
  - `PositionGroup`: variant layout mapping each app (by bundleID) to a `Corner` via `AppPositionMapping`.
  - `PositionTemplate`: predefined corner/half/thirds combos; used to seed `PositionGroup`s; matched by `PositionGroupTemplateMatcher` for iconography.

- Pinning engine (`PinCore.swift`):
  - `Corner` enumerates positions (corners, halves, thirds, two‑thirds, fullScreen).
  - `PinSpec` carries corner, widthFraction, heightPoints, marginX/Y.
  - `Actions.summon(bundleID:spec:screen)`: ensure AX permission, locate or create window, activate app, unminimize, compute `pinnedRectSafe`, anchor via `axSetFrameAnchored` with force-exact sizing for half positions, then `ensureRightAnchoredAlignment` to respect minimum widths on right‑anchored layouts.
  - `axSetFrameAnchored(...)`: size first, compute margins from target rect, optionally force exact half‑screen size, calculate anchored origin (dual‑anchor logic for halves), convert to AX top‑left, set position; performs a 50ms invisible height enforcement pass for stubborn apps; snaps to device pixels.
  - Alignment helpers: `anchors(for:)`, `isHalfScreenPosition`, `snap`, and right‑anchor correction that keeps X aligned even when app refuses narrower widths.
  - Window discovery: robust AX queries with retry, menu traversal fallback to create a new window if needed; minimize/unminimize helpers; safe geometry within `screen.visibleFrame`.

- App orchestration (`AppState.swift`):
  - Holds selection state (`selectedConfigurationID`, `selectedPositionGroupForConfig`), menu bar manager, and SwiftData `ModelContext`.
  - Keyboard shortcuts: activate current configuration, cycle forward/back, cycle position groups, toggle menu bar; uses stable sort by `lastActivatedAt` (fallback `dateCreated`) and does not update timestamps during cycling.
  - `applyConfigurationWithSelectedGroup(_)`: resolves active `PositionGroup`, builds `PinSpec` per app, calls `Actions.summon` with 10ms stagger for smooth activation.
  - Data/perf: manual fetches replace `@Query`; cached running apps; `configurationDataVersion` to signal UI refresh after edits.

- App setup (`DirishaApp.swift`):
  - Initializes SwiftData container (Item, SavedApp, ConfigurationGroup, AppConfiguration, PositionGroup, AppPositionMapping) and configures CloudKit with container `iCloud.SUY4TDSAGW.zuriapps.Dirisha`.
  - Creates single window scene; sets up menu bar manager; applies centralized appearance on launch and changes; auto-selects most recent configuration without activation.

Cloud Sync (SwiftData + CloudKit) - **MAJOR MIGRATION COMPLETED 2024-09-28**
- **Full CloudKit integration achieved**: All configurations, apps, and position groups now sync seamlessly across devices via iCloud private database.
- **Model compliance**: All SwiftData models fully updated for CloudKit rules - every attribute optional or has default; all relationships optional with proper inverses and delete rules (`.cascade` for parent-child, `.nullify` for references). Computed properties marked `@Transient` to avoid persistence.
- **Relationship structure**: `ConfigurationGroup` ↔ `AppConfiguration` (cascade); `ConfigurationGroup` ↔ `PositionGroup` (cascade); `PositionGroup` ↔ `AppPositionMapping` (cascade); `SavedApp` ↔ `AppConfiguration` (nullify).
- **Schema configuration**: SwiftData container uses `Schema([...])` format with `ModelConfiguration(cloudKitDatabase: .private("iCloud.SUY4TDSAGW.zuriapps.Dirisha"))` registering all 6 model types.
- **App entitlements**: CloudKit capability enabled with container `iCloud.SUY4TDSAGW.zuriapps.Dirisha` properly configured.
- **Codebase adaptation**: Comprehensive updates across 5+ view files to handle optional relationships safely using `?? []` patterns, optional chaining, and nil-coalescing operators. All array operations (count, contains, append, removeAll) now CloudKit-compatible.
- **Migration strategy**: Clean start approach with local SwiftData store reset to ensure CloudKit compatibility; new configurations sync seamlessly to iCloud.
- **Manual sync controls**: Settings include iCloud account status monitoring, manual "Sync Now" button, sync status indicators, and data export functionality for testing and user control.

Distribution and App Store Connect Limitations - **CRITICAL CONSTRAINT 2024-09-28**
- **App Store Connect incompatibility**: Validation requires `com.apple.security.app-sandbox` entitlement set to `true`, but enabling App Sandbox completely breaks window activation functionality - users cannot activate/position windows anymore.
- **Current entitlements**: App Sandbox disabled (`<false/>`) to preserve core window management functionality; CloudKit container `iCloud.SUY4TDSAGW.zuriapps.Dirisha` properly configured for sync.
- **Distribution strategy**: Direct/independent distribution only - cannot distribute through Mac App Store due to sandbox restrictions conflicting with essential system-level window manipulation permissions.
- **Industry precedent**: Similar window management apps (Rectangle, Magnet, etc.) face the same sandbox limitations and often distribute independently to maintain full functionality.
- **Technical conflict**: Window management requires extensive system permissions (Accessibility API, window control across apps) that are fundamentally incompatible with App Sandbox security model.

Independent App Updates Strategy - **IMPLEMENTATION NEEDED 2024-09-28**
- **Challenge**: Gumroad distribution bypasses Mac App Store's automatic update mechanism - need custom update system for seamless user experience.
- **Solution**: **Sparkle Framework** integration for professional-grade automatic updates, providing seamless user experience comparable to App Store apps.
- **Status**: Planning phase - comprehensive implementation strategy documented in dedicated App Updates context folder.
- **Key Benefits**: Non-intrusive update notifications, secure RSA signature verification, delta updates, automatic relaunch, user preferences for update frequency.

Multi-monitor: `MultiMonitorHelper.moveWindowToNextDisplay` now mirrors Rectangle's relative-geometry move; retains layout proportions while migrating windows across displays.



