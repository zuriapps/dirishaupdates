# Status Bar Icon Color Bug

## Problem Description
Status bar icon appearance is incorrectly influenced by the app's internal theme setting instead of following the system's menu bar appearance.

### Current Behavior
- When app theme is set to "Light": Status bar icon becomes black (incorrect)
- When app theme is set to "Dark": Status bar icon becomes white (incorrect)
- Icon should follow system menu bar appearance based on wallpaper contrast, not app theme

### Expected Behavior
Status bar icon should exclusively follow macOS system menu bar theming:
- Dark icons on light menu bars (light wallpapers)
- Light icons on dark menu bars (dark wallpapers)
- Independent of app's internal theme setting

## Root Cause Analysis
The app's `applyAppearance()` method in `AppState.swift` applies the selected theme to ALL windows, including the status bar button's window. This overrides the system's automatic menu bar theming.

## Failed Solution Attempts

### Attempt 1: Simple appearance clearing
- Modified `protectStatusBarAppearance()` to set `button.appearance = nil`
- Result: Partially effective but still influenced by app theme changes

### Attempt 2: Exclude status bar windows from app theming
- Added filter in `AppState.swift` to skip `window.level == .statusBar`
- Enhanced protection to clear both button and window appearance
- Result: **Broke main window theming** - had to revert

## Technical Constraints
- Cannot modify the main app theming loop without affecting other windows
- Status bar button window is managed by system, limited control over its appearance
- Template images should automatically adapt but are being overridden

## Potential Solutions to Explore
1. **Delayed protection**: Apply protection with longer delays after theme changes
2. **Observation-based approach**: Monitor appearance changes and immediately counter them
3. **Alternative icon approach**: Use different icon rendering method less susceptible to appearance override
4. **System notification handling**: Hook into system appearance change notifications separately

## Files Involved
- `AppState.swift:401-420` - Main appearance application logic
- `MenuBarManager.swift:58-65` - Status bar appearance protection
- `MenuBarManager.swift:122-124` - Public protection method

## Impact
- Visual inconsistency in menu bar
- User confusion when icon doesn't match system appearance expectations
- Professional appearance degradation

## Status
- **Open** - Needs alternative solution approach
- Previous fix attempts reverted due to side effects
- Requires isolated solution that doesn't affect main window theming