# Main App Mode – UI Bug Fixes Log

Use this file to record concise entries for UI bug fixes or changes that affect the main (windowed) app mode.

Entry template:
- Title: Short description (e.g., "Fix: Dropdown truncation and height consistency")
- Date: YYYY-MM-DD
- Type: Bug Fix | UX | Perf | Refactor
- Files: e.g., `AppConfigurationsSectionView.swift`
- Summary: 1–3 lines of what changed and why
- Outcome: 1 line on the result/impact

---

### Fix: Adaptive height scaling excessive stretching on 4K monitors
- Date: 2025-09-26
- Type: Bug Fix
- Files: `MainView.swift:44-60`
- Summary: Fixed `adaptiveMainMinHeight` calculation that was causing massive window stretching on large 4K monitors. The original 82% scaling factor worked for small screens but created unusable tall windows on 4K displays. Implemented tiered scaling: 35% for 4K+ displays (≥2000px height), 60% for large displays (≥1200px), and original 82% for small displays. Added maximum height cap of 900px for usability.
- Outcome: Main app window now maintains reasonable proportions across all screen sizes from 13" MacBooks to 42" 4K monitors
