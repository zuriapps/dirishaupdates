# App Setup (DirishaApp) – Changes & Decisions Log

Scope: `DirishaApp.swift` app lifecycle, SwiftData container setup, scene/window configuration, appearance application, and launch auto-selection.

Entry template:
- Title: Short description (e.g., "Apply appearance at willFinishLaunching to avoid light→dark flash")
- Date: YYYY-MM-DD
- Type: Setup | Bug Fix | Perf | Refactor
- Files: e.g., `DirishaApp.swift`, `AppDelegate`
- Summary: 1–3 lines of what changed and why
- Impact: Startup behavior, appearance correctness, or reliability
