# Swift Data – Changes & Decisions Log

Use this file to document changes to SwiftData models, migrations, fetch strategies, and performance adjustments.

Entry template:
- Title: Short description (e.g., "Replace @Query with manual FetchDescriptor in heavy views")
- Date: YYYY-MM-DD
- Type: Model | Migration | Perf | API | Refactor
- Files: e.g., `Item.swift`, `ContentView.swift`
- Summary: 1–3 lines of what changed and why
- Impact: Developer- and user-facing outcomes (perf, UX, data integrity)

---

## CloudKit Migration - Complete Model Overhaul for Cloud Sync
- **Date**: 2024-09-28
- **Type**: Model | Migration | API
- **Files**: `Item.swift`, `DirishaApp.swift`, `AppState.swift`, `AppConfigurationsSectionView.swift`, `MinimizedHomeView.swift`, `EditConfigurationModalView.swift`, `PositionGroupTemplateMatcher.swift`
- **Summary**: Migrated all SwiftData models to be CloudKit-compatible by making relationships optional, adding proper delete rules, fixing circular references, and updating all consuming code to handle optional arrays. Models now sync across devices via iCloud private database.
- **Impact**:
  - **User**: Full cross-device synchronization of configurations, apps, and position groups via iCloud
  - **Developer**: Major breaking change requiring optional unwrapping throughout codebase, but enables cloud sync capability
  - **Data**: All existing local data preserved, now syncs to CloudKit private database container `iCloud.SUY4TDSAGW.zuriapps.Dirisha`

### Key Model Changes:
- **All relationships made optional**: `configurations: [AppConfiguration]?`, `positionGroups: [PositionGroup]?`, etc.
- **Added inverse relationship declarations**: All `@Relationship` attributes specify inverse for CloudKit compatibility
- **Delete rule specifications**: Parent-child relationships use `.cascade`, reference relationships use `.nullify`
- **Fixed circular references**: Removed problematic bidirectional `@Relationship` macros that caused compiler errors
- **Schema initialization**: Updated `ModelContainer` to use `Schema([...])` instead of array of model types
- **Transient computed properties**: All computed properties marked `@Transient` to avoid CloudKit persistence

### Codebase Updates for Optional Arrays:
- **Array iteration**: `configuration.configurations ?? []` pattern throughout
- **Count operations**: `configuration.configurations?.count ?? 0` for safe counting
- **Contains operations**: `(configuration.configurations ?? []).contains` for membership testing
- **Append operations**: Added nil initialization checks (`if configurations == nil { configurations = [] }`)
- **RemoveAll operations**: Using optional chaining `configurations?.removeAll`
- **First/enumeration**: Optional chaining for `positionGroups?.first` and `configurations?.enumerated()`

### Views Updated:
1. **AppState.swift**: Position group cycling, configuration application logic
2. **AppConfigurationsSectionView.swift**: Main configuration management view (16+ fixes)
3. **MinimizedHomeView.swift**: Menu bar interface for configuration management
4. **EditConfigurationModalView.swift**: Configuration editing modal (25+ fixes)
5. **PositionGroupTemplateMatcher.swift**: Template matching utilities

### CloudKit Configuration:
- **Container**: `iCloud.SUY4TDSAGW.zuriapps.Dirisha` in private database
- **Entitlements**: CloudKit capability enabled with container reference
- **Model registration**: All 6 model types registered with CloudKit-enabled schema
- **Automatic sync**: SwiftData handles CloudKit synchronization automatically

### Breaking Changes:
- All relationship arrays now optional - requires `?? []` fallbacks in iteration
- Array operations require nil checks or optional chaining
- Model initialization may need array property setup for new instances
- Views must handle empty/nil relationship states gracefully

### Migration Strategy:
- **Clean start approach used**: Local SwiftData store deleted to avoid schema conflicts with CloudKit
- Fresh database created with CloudKit-compatible schema from day one
- New configurations created post-migration will sync seamlessly to iCloud
- This approach eliminates potential data corruption from schema mismatches
- Subsequent app installs will automatically download cloud data

### Database Reset Method:
```swift
// Method used to clear local store for clean CloudKit migration
private static func deleteLocalSwiftDataStore() throws {
    let fm = FileManager.default
    let supportURL = try fm.url(for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let base = supportURL.appendingPathComponent("default.store")
    let candidates = [base, URL(fileURLWithPath: base.path + "-wal"), URL(fileURLWithPath: base.path + "-shm")]
    for url in candidates {
        if fm.fileExists(atPath: url.path) {
            try fm.removeItem(at: url)
        }
    }
}
```

---

## Manual CloudKit Sync Feature Added
- **Date**: 2024-09-28
- **Type**: API | Feature
- **Files**: `SettingsView.swift`
- **Summary**: Added manual iCloud sync functionality in Settings with real-time status monitoring, account verification, and data export capabilities for better CloudKit testing and user control.
- **Impact**:
  - **User**: Manual "Sync Now" button for immediate CloudKit synchronization, status indicators for account and sync state, data export functionality for backup
  - **Developer**: Better debugging tools for CloudKit sync issues, clear sync status feedback, ability to force sync operations
  - **Testing**: Easier verification of cross-device sync functionality, immediate feedback on sync operations

### Features Added:
- **iCloud Account Status**: Real-time monitoring of CloudKit account availability
- **Manual Sync Button**: Force immediate CloudKit synchronization with progress indicator
- **Sync Status Display**: Visual indicators for sync state (Ready/Syncing/Synced/Error)
- **Last Sync Time**: Relative timestamp showing when last sync occurred
- **Data Export**: JSON backup functionality for configuration data
- **Error Handling**: Graceful error display and recovery for sync operations

### UI Components:
- Status indicators with color coding (green=good, red=error, orange=pending)
- Progress spinner during sync operations
- Disabled states when iCloud unavailable
- Relative date formatting for last sync time

### Implementation Details:
- Uses `CKContainer.accountStatus()` to verify iCloud availability
- Triggers sync via SwiftData `save()` operations to force CloudKit updates
- Includes simulated delay for better UX during sync operations
- Export functionality creates timestamped JSON backups with configuration metadata
