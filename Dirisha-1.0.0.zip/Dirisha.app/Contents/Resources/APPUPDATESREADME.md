App Updates System - Sparkle Framework Integration
===================================================

## Overview
Dirisha uses the Sparkle framework for independent app updates since Mac App Store distribution is impossible due to sandbox constraints. This system provides seamless, secure automatic updates for users who purchased through Gumroad or other direct distribution channels.

## Architecture Decision
**Problem**: App Store Connect requires App Sandbox enabled, but this completely breaks window management functionality.
**Solution**: Independent distribution + Sparkle framework for professional-grade automatic updates.

## Sparkle Framework Integration

### Core Components
- **Sparkle Swift Package**: Modern Swift-based updater framework
- **Appcast XML**: Server-hosted metadata file describing available versions
- **RSA Signature System**: Security verification for update packages
- **Delta Updates**: Efficient incremental updates for smaller downloads

### Implementation Status
- [x] **Package Integration**: Add Sparkle via Swift Package Manager *(2024-09-29)*
- [x] **Basic Controller Setup**: SPUUpdaterController added to AppDelegate *(2024-09-29)*
- [x] **Appcast Setup**: Created appcast.xml file in DirishaUpdates repo *(2024-09-29)*
- [x] **Security Setup**: Generated EdDSA keys for signature verification *(2024-09-29)*
- [x] **Info.plist Configuration**: Created custom Info.plist with Sparkle settings *(2024-09-29)*
- [x] **Menu Integration**: Added "Check for Updates..." to app menu with Cmd+U shortcut *(2024-09-29)*
- [ ] **Automatic Checking**: Weekly update checks with user preferences
- [ ] **Initial Release**: Create signed ZIP and update appcast with signature

### File Structure
```
Dirisha/
├── Info.plist                 # Sparkle configuration
├── DirishaApp.swift           # Sparkle initialization
└── Views/
    └── SettingsView.swift     # Update preferences UI
```

### Configuration Requirements

#### Info.plist Additions
```xml
<key>SUFeedURL</key>
<string>https://zuriapps.github.io/dirishaupdates/appcast.xml</string>
<key>SUPublicEDKey</key>
<string>[GENERATED_EDDSA_PUBLIC_KEY]</string>
<key>SUEnableAutomaticChecks</key>
<true/>
<key>SUScheduledCheckInterval</key>
<integer>604800</integer> <!-- 7 days -->
```

#### Appcast XML Structure
```xml
<?xml version="1.0" encoding="utf-8"?>
<rss version="2.0" xmlns:sparkle="http://www.andymatuschak.org/xml-namespaces/sparkle">
  <channel>
    <title>Dirisha Updates</title>
    <item>
      <title>Version 1.1.0</title>
      <pubDate>Mon, 28 Sep 2024 12:00:00 +0000</pubDate>
      <sparkle:version>1.1.0</sparkle:version>
      <sparkle:shortVersionString>1.1.0</sparkle:shortVersionString>
      <enclosure url="https://yourdomain.com/dirisha/Dirisha-1.1.0.dmg"
                 sparkle:edSignature="[SIGNATURE]"
                 length="12345678"
                 type="application/octet-stream"/>
      <sparkle:minimumSystemVersion>13.0</sparkle:minimumSystemVersion>
      <description><![CDATA[
        <h3>What's New</h3>
        <ul>
          <li>Feature improvements</li>
          <li>Bug fixes</li>
        </ul>
      ]]></description>
    </item>
  </channel>
</rss>
```

## Update Distribution Workflow

### 1. Version Preparation
- Update version numbers in `Info.plist` and project settings
- Follow semantic versioning (e.g., 1.0.0 → 1.0.1 for patches, 1.1.0 for features)
- Update `CFBundleShortVersionString` and `CFBundleVersion`

### 2. Build & Package
```bash
# Clean build
xcodebuild clean -project Dirisha.xcodeproj -scheme Dirisha

# Archive for distribution
xcodebuild archive -project Dirisha.xcodeproj -scheme Dirisha -archivePath Dirisha.xcarchive

# Export as signed app
xcodebuild -exportArchive -archivePath Dirisha.xcarchive -exportPath Export -exportOptionsPlist export.plist

# Create DMG
create-dmg --volname "Dirisha" --window-size 600 400 Dirisha-1.1.0.dmg Export/
```

### 3. Notarization
```bash
# Submit for notarization
xcrun notarytool submit Dirisha-1.1.0.dmg --apple-id your@email.com --team-id TEAMID --wait

# Staple notarization
xcrun stapler staple Dirisha-1.1.0.dmg
```

### 4. Appcast Update
- Generate Sparkle signature for new DMG
- Update appcast.xml with new version info
- Upload to web server before Gumroad release

### 5. Distribution
- Upload to Gumroad with updated description
- Update appcast.xml simultaneously
- Existing users receive update notifications within 24-48 hours

## Security Considerations

### Code Signing
- All updates must be signed with same Developer ID certificate
- Maintain certificate continuity for user trust
- Regular certificate renewal before expiration

### Signature Verification
- RSA signatures prevent tampering during download
- HTTPS-only download URLs for man-in-the-middle protection
- Apple notarization adds additional security layer

### User Privacy
- No personal data collected during update checks
- Anonymous version checking only
- User can disable automatic checks in preferences

## User Experience Features

### Update Notifications
- Non-intrusive notification when updates available
- Option to install now, later, or skip version
- Release notes displayed in native format

### Preferences
- Enable/disable automatic checking
- Adjust check frequency (daily, weekly, monthly)
- Beta/stable channel selection (future enhancement)

### Progress Feedback
- Download progress indicator
- Installation status
- Automatic app relaunch after update

## Testing Strategy

### Development Testing
- Local appcast server for development builds
- Test update flow from older versions
- Verify signature validation and rollback scenarios

### Release Testing
- Staged rollout to subset of users
- Monitor crash reports and feedback
- Quick rollback capability via appcast modification

## Maintenance

### Regular Tasks
- Monitor appcast server uptime and performance
- Update RSA keys periodically for security
- Clean up old version files to save server space

### Emergency Procedures
- Immediate appcast update for critical security patches
- Communication channels for user notification
- Rollback procedures for problematic updates

## Integration Points

### App Menu
```swift
// Add to main menu structure
Menu("Dirisha") {
    // ... other items
    Divider()
    Button("Check for Updates...") {
        updater.checkForUpdates()
    }
}
```

### Settings Integration
- Update preferences in SettingsView
- Visual indicators for update status
- Manual check button and last-checked timestamp

### Startup Integration
- Initialize Sparkle in DirishaApp.swift
- Respect user preferences for automatic checking
- Handle first-run scenarios gracefully

## Future Enhancements

### Planned Features
- [ ] Beta channel support for early adopters
- [ ] Delta updates for minimal download sizes
- [ ] Update scheduling (install at next quit)
- [ ] Detailed update history in app

### Analytics Integration
- Optional anonymous usage metrics
- Update success/failure rates
- Version adoption tracking

## Troubleshooting

### Common Issues
- **Certificate expiration**: Users see security warnings
- **Appcast server down**: Updates fail silently
- **Signature mismatch**: Updates rejected by Sparkle

### Debug Mode
- Enable Sparkle debug logging for troubleshooting
- User-accessible logs for support requests
- Verbose update status in development builds

---

**Last Updated**: 2024-09-29
**Implementation Status**: Initial Setup Complete - Basic Sparkle Integration
**Priority**: High (Required for independent distribution)

## Next Steps - Implementation Checklist

### 🔐 Security Setup (CRITICAL)
- [x] **Generate EdDSA signing keys**: Generated using OpenSSL Ed25519 algorithm *(2024-09-29)*
- [x] **Store private key securely**: Stored at `~/.sparkle-keys/private_key.pem` with 600 permissions *(2024-09-29)*
- [x] **Add public key to Info.plist**: Created custom Info.plist with SUPublicEDKey configuration *(2024-09-29)*

### 📝 Configuration Tasks
- [x] **Update Info.plist**: Added all required Sparkle keys (SUFeedURL, SUPublicEDKey, etc.) *(2024-09-29)*
- [x] **Test appcast URL**: Verified https://zuriapps.github.io/dirishaupdates/appcast.xml is accessible *(2024-09-29)*
- [ ] **Configure GitHub Pages**: Enable GitHub Pages for DirishaUpdates repository

### 🏗️ Build & Release Process
- [ ] **Create first release**: Build, sign, and ZIP the current version
- [ ] **Generate release signature**: Use private key to sign the ZIP file
- [ ] **Update appcast.xml**: Add actual file size, download URL, and signature
- [ ] **Upload to GitHub releases**: Create v1.0 release with ZIP file

### 🧪 Testing & Validation
- [ ] **Test update mechanism**: Create a fake newer version to test update flow
- [ ] **Verify signatures**: Ensure signature validation works correctly
- [ ] **Test rollback scenario**: Verify handling of failed updates

## Recent Changes

### 2024-09-29 - Settings View Integration
- ✅ Added "Check for Updates" button to About section in SettingsView
- ✅ Implemented glassmorphic button styling matching Sync Now button
- ✅ Button positioned centrally with proper spacing and padding
- ✅ Successfully built and verified all integration points working
- ✅ Update mechanism now accessible from both application menu and settings

### 2024-09-29 - Menu Integration & Testing
- ✅ Added "Check for Updates..." menu item to main application menu
- ✅ Configured keyboard shortcut (Cmd+U) for update checking
- ✅ Implemented CommandGroup integration in SwiftUI app structure
- ✅ Successfully built and tested app with menu integration
- ✅ Verified appcast URL accessibility (https://zuriapps.github.io/dirishaupdates/appcast.xml)
- ✅ Update mechanism now properly accessible via application menu

### 2024-09-29 - Info.plist Configuration & Project Setup
- ✅ Created custom Info.plist file at `Dirisha/Info.plist`
- ✅ Added complete Sparkle configuration including:
  - SUFeedURL: https://zuriapps.github.io/dirishaupdates/appcast.xml
  - SUPublicEDKey: MCowBQYDK2VwAyEAJdJc9u+egjbHVkqNTcsgVRUBYyp5I70fuhkknqiD0Ro=
  - SUEnableAutomaticChecks: true (weekly checks)
  - SUShowReleaseNotes: true
- ✅ Updated Xcode project to use custom Info.plist instead of generated one
- ✅ Configured both Debug and Release build configurations
- ✅ Verified build success with new configuration
- ✅ Fixed LSMinimumSystemVersion to match deployment target (15.0)

### 2024-09-29 - EdDSA Key Generation & Security Setup
- ✅ Generated EdDSA signing keys using OpenSSL Ed25519 algorithm
- ✅ Public key (base64): `MCowBQYDK2VwAyEAJdJc9u+egjbHVkqNTcsgVRUBYyp5I70fuhkknqiD0Ro=`
- ✅ Private key stored securely at `~/.sparkle-keys/private_key.pem` (600 permissions)

### 2024-09-29 - Appcast & Repository Setup
- ✅ Created appcast.xml in DirishaUpdates repository (`/Users/ericlesrima/Apps/DirishaUpdates/appcast.xml`)
- ✅ Set up GitHub repository for hosting updates at https://github.com/zuriapps/dirishaupdates
- ✅ Configured GitHub Pages URL structure (https://zuriapps.github.io/dirishaupdates/appcast.xml)
- ✅ Added comprehensive implementation checklist

### 2024-09-29 - Initial Sparkle Integration
- ✅ Installed Sparkle framework via Swift Package Manager
- ✅ Added basic SPUUpdaterController to AppDelegate
- ✅ Created comprehensive documentation structure
- 🔄 Ready for full implementation phase
