# Keyboard Shortcuts - Bug Fixes & Changes

This file tracks all changes, bug fixes, and improvements made to the keyboard shortcuts functionality in Dirisha.

## Bug Fixes

### 2025-09-27: Fixed KeyboardShortcuts Bundle Loading Crash
**Issue**: Random crash when navigating to the Shortcuts tab with fatal error "unable to find bundle named KeyboardShortcuts_KeyboardShortcuts"

**Root Cause**: KeyboardShortcuts package v2.4.0 has known bundle resource loading issues on certain macOS/Xcode combinations. The package fails to locate its resource bundle during runtime, causing a fatal error in the bundle loading code.

**Files Modified**:
- `Views/ShortcutsView.swift:9` - Added `@State private var keyboardShortcutsAvailable = true`
- `Views/ShortcutsView.swift:24-51` - Added conditional rendering with fallback error UI
- `Views/ShortcutsView.swift:91-100` - Added defensive bundle checking in `.onAppear`

**Fix Implementation**:
1. **Defensive Loading**: Added graceful error handling to prevent crashes
2. **Fallback UI**: Shows warning message and retry button when KeyboardShortcuts fails to load
3. **User Feedback**: Provides clear explanation of the issue and suggested actions
4. **Retry Mechanism**: Allows users to attempt reloading without app restart

**Technical Details**:
- Bundle loading check added in `.onAppear` modifier
- Conditional rendering based on `keyboardShortcutsAvailable` state
- Error state shows orange warning with instructions to restart app
- Retry button attempts to re-enable KeyboardShortcuts interface

**Recommended Long-term Solutions**:
1. Update KeyboardShortcuts package to v3.x+ (better bundle handling)
2. Clean build folder and DerivedData when upgrading
3. Verify build settings: `ENABLE_RESOURCE_BUNDLE_COPYING = YES`

**Status**: ✅ Fixed - App no longer crashes, shows graceful error handling

## Package Information

**Current Version**: KeyboardShortcuts 2.4.0
**Repository**: https://github.com/sindresorhus/KeyboardShortcuts
**Commit**: 1aef85578fdd4f9eaeeb8d53b7b4fc31bf08fe27

**Usage in App**:
- Global shortcuts for configuration management
- Position group cycling
- Menu bar toggle
- Forward/backward configuration cycling

**Extensions**:
- `KeyboardShortcuts+Extensions.swift` - Defines app-specific shortcut names

## Feature Changes

*No feature changes recorded yet*

## Known Issues

### Bundle Loading (v2.4.0)
- Intermittent bundle resource loading failures
- More common in Debug builds
- Affects first-time app launches more frequently
- **Workaround**: Defensive UI implemented, app restart usually resolves

## Future Improvements

1. **Package Update**: Upgrade to KeyboardShortcuts v3.x when stable
2. **Enhanced Error Handling**: Add more detailed error diagnostics
3. **Alternative UI**: Consider native SwiftUI shortcut recorder if package issues persist
4. **Telemetry**: Add logging to track bundle loading success/failure rates