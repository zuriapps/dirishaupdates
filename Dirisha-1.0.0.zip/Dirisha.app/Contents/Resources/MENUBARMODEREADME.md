# Menu Bar Mode – UI Bug Fixes Log

Use this file to record concise entries for UI bug fixes or changes that affect the attached menu bar mode.

Entry template:
- Title: Short description (e.g., "Fix: Instant re-anchor after tab height change")
- Date: YYYY-MM-DD
- Type: Bug Fix | UX | Perf | Refactor
- Files: e.g., `MenuBarManager.swift`, `MainView.swift`
- Summary: 1–3 lines of what changed and why
- Outcome: 1 line on the result/impact

---

## Bug Fixes

### Fix: Status bar icon forced white appearance ignoring system theming
- Date: 2025-09-28
- Type: Bug Fix
- Files: `MenuBarManager.swift`, `AppState.swift`
- Summary: Hardened status bar appearance protection by recursively clearing appearances on the status bar button window with exponential backoff retries whenever app theme changes. Ensures template icon stays under system control while keeping main window theming intact.
- Outcome: Status bar icon now consistently follows macOS menu bar contrast regardless of app theme changes.

### Fix: Window positioning flash on menu bar mode launch
- Date: 2025-09-28
- Type: Bug Fix
- Files: `MenuBarManager.swift`, `DirishaApp.swift`
- Summary: Added `showAttachedWindowForLaunch()` method that starts window invisible (alpha=0), waits for status bar button readiness, positions window correctly, then fades in smoothly with 2ms delay. Enhanced window hiding in launch sequence to prevent any visibility at default position.
- Outcome: Eliminated random window flash at top-left corner during menu bar mode launch, ensuring smooth transition directly to status bar position.

### Fix: Dock icon visible only in main window mode
- Date: 2025-09-28
- Type: UX
- Files: `MenuBarManager.swift`, `AppState.swift`
- Summary: Updated smart dock policy so the app shows its dock icon whenever the main window is detached, hides it while attached menu bar mode is active, and auto-attaches when keyboard shortcuts run.
- Outcome: Dock icon now stays available in main window mode, disappears during menu bar usage, and shortcuts immediately reveal the attached window.

### Feature: Optional main window display on status bar click
- Date: 2025-09-28
- Type: UX
- Files: `SettingsModel.swift`, `MenuBarManager.swift`, `SettingsView.swift`
- Summary: Added "Show Main Window on Status Bar Click" setting (default: false) that allows users to show the main window at its current position when clicking the status bar icon from main window mode, instead of entering menu bar mode. Setting preserves original behavior when disabled.
- Outcome: Users can now choose between entering menu bar mode or simply bringing up their main window when clicking the status bar icon.
