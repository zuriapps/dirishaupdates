# Pinning Engine (PinCore) – Changes & Bug Fixes Log

Scope: `PinCore.swift` window positioning pipeline (AX queries, window discovery, sizing, anchoring, alignment), and geometry helpers.

Entry template:
- Title: Short description (e.g., "Invisible height enforcement after half-screen resize")
- Date: YYYY-MM-DD
- Type: Bug Fix | Perf | Refactor | API
- Files: e.g., `PinCore.swift`
- Summary: 1–3 lines of what changed and why
- Impact: Behavior, performance, or reliability improvements
