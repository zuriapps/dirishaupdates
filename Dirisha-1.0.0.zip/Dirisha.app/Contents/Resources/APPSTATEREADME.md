# App Orchestration (AppState) – Changes & Decisions Log

Scope: `AppState.swift` orchestration (selection state, keyboard shortcuts, menu bar manager integration, data refresh triggers, caches).

Entry template:
- Title: Short description (e.g., "Stable cycling without timestamp updates")
- Date: YYYY-MM-DD
- Type: Feature | Bug Fix | Perf | Refactor
- Files: e.g., `AppState.swift`, `KeyboardShortcuts+Extensions.swift`
- Summary: 1–3 lines of what changed and why
- Impact: UX or internal consistency improvements
